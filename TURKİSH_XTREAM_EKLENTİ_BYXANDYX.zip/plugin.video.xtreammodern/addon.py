import sys
import os
import urllib.parse
import xbmcgui
from xbmcgui import ListItem, Dialog
from xbmcplugin import addDirectoryItem, endOfDirectory, setContent, setResolvedUrl
import xbmcaddon
import xbmc

# Kendi kütüphanemizi ekleyelim
sys.path.append(os.path.join(os.path.dirname(__file__), 'resources', 'lib'))
from xtream_api import XtreamAPI

# Eklenti bilgileri
ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON_PATH = ADDON.getAddonInfo('path')

def get_params():
    param_string = sys.argv[2][1:]
    if param_string:
        return dict(urllib.parse.parse_qsl(param_string))
    return {}

def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"--- [Xtream Modern] {msg}", level)

def build_url(query):
    return BASE_URL + '?' + urllib.parse.urlencode(query)

def get_asset(filename):
    """Eklenti içindeki kaynak dosyasının tam yolunu döner."""
    return os.path.join(ADDON_PATH, 'resources', filename)

def run_setup_wizard():
    """Kullanıcı bilgileri eksikse ekranda klavye açarak sorar."""
    dialog = Dialog()
    
    host = dialog.input('Xtream Sunucu Adresi (Örn: http://server.com:8080)', type=xbmcgui.INPUT_ALPHANUM)
    if not host: return False
    
    user = dialog.input('Kullanıcı Adı', type=xbmcgui.INPUT_ALPHANUM)
    if not user: return False
    
    pw = dialog.input('Şifre', type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not pw: return False
    
    # Bilgileri kaydet
    ADDON.setSetting('host', host)
    ADDON.setSetting('username', user)
    ADDON.setSetting('password', pw)
    
    dialog.notification('Başarılı', 'Giriş bilgileri kaydedildi.', xbmcgui.NOTIFICATION_INFO)
    return True

def get_api():
    host = ADDON.getSetting('host')
    user = ADDON.getSetting('username')
    pw = ADDON.getSetting('password')
    
    if not host or not user or not pw:
        # Eğer bilgiler yoksa sihirbazı çalıştır
        if run_setup_wizard():
            return get_api() # Yeniden dene
        return None
    
    return XtreamAPI(host, user, pw)

def main_menu():
    api = get_api()
    if not api: return

    # Otomatik giriş kontrolü
    success, data = api.authenticate()
    if not success:
        Dialog().ok('Giriş Hatası', str(data))
        ADDON.openSettings()
        return

    # Netflix Tarzı Izgara Görünümü
    setContent(HANDLE, 'movies')
    fanart = os.path.join(ADDON_PATH, 'fanart.jpg')

    items = [
        ('Canlı TV', {'action': 'categories', 'type': 'live'}, get_asset('live_tv.png')),
        ('Sinema (VOD)', {'action': 'categories', 'type': 'vod'}, get_asset('movies.png')),
        ('Diziler', {'action': 'categories', 'type': 'series'}, get_asset('series.png')),
        ('Ayarlar', {'action': 'settings'}, get_asset('settings.png'))
    ]

    for label, query, icon in items:
        list_item = ListItem(label)
        list_item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'fanart': fanart})
        url = build_url(query)
        addDirectoryItem(HANDLE, url, list_item, isFolder=(query['action'] != 'settings'))
    
    xbmc.executebuiltin('Container.SetViewMode(500)')
    endOfDirectory(HANDLE)

def list_categories(content_type):
    api = get_api()
    if not api: return
    
    categories = api.get_categories(content_type)
    setContent(HANDLE, 'movies')
    fanart = os.path.join(ADDON_PATH, 'fanart.jpg')

    all_item = ListItem("Tüm İçerikler")
    all_item.setArt({'fanart': fanart})
    all_url = build_url({'action': 'list', 'type': content_type, 'cat_id': '0'})
    addDirectoryItem(HANDLE, all_url, all_item, isFolder=True)

    for cat in categories:
        cat_name = cat.get('category_name', 'Bilinmeyen')
        cat_id = cat.get('category_id')
        
        list_item = ListItem(cat_name)
        list_item.setArt({'fanart': fanart})
        url = build_url({'action': 'list', 'type': content_type, 'cat_id': cat_id})
        addDirectoryItem(HANDLE, url, list_item, isFolder=True)
    
    xbmc.executebuiltin('Container.SetViewMode(500)')
    endOfDirectory(HANDLE)

def list_content(content_type, cat_id):
    api = get_api()
    if not api: return
    
    setContent(HANDLE, 'movies' if content_type != 'live' else 'lives')
    streams = api.get_streams(cat_id, content_type)
    fanart = os.path.join(ADDON_PATH, 'fanart.jpg')
    
    for item in streams:
        name = item.get('name', 'Adsız')
        # stream_id, series_id veya id anahtarlarına bak
        stream_id = item.get('stream_id') or item.get('series_id') or item.get('id')
        icon = item.get('stream_icon') or item.get('cover')
        # Uzantı bilgisi null gelirse mp4 olarak varsayıyoruz
        container = item.get('container_extension') or 'mp4' 
        
        if not stream_id or str(stream_id) == 'None':
            log(f"ID eksik olan icerik atlandi: {name}")
            continue

        list_item = ListItem(name)
        list_item.setInfo('video', {
            'title': name,
            'plot': item.get('plot', ''),
            'genre': item.get('genre', ''),
            'rating': item.get('rating', ''),
            'year': item.get('year', '')
        })
        
        list_item.setArt({'thumb': icon, 'poster': icon, 'fanart': fanart})
        
        if content_type == 'series':
            url = build_url({'action': 'seasons', 'series_id': stream_id})
            addDirectoryItem(HANDLE, url, list_item, isFolder=True)
        else:
            url = build_url({'action': 'play', 'type': content_type, 'id': stream_id, 'container': container, 'name': name})
            list_item.setProperty('IsPlayable', 'true')
            addDirectoryItem(HANDLE, url, list_item, isFolder=False)
            
    xbmc.executebuiltin('Container.SetViewMode(500)')
    endOfDirectory(HANDLE)

def list_seasons(series_id):
    api = get_api()
    if not api: return
    
    data = api.get_series_info(series_id)
    seasons_data = data.get('seasons', [])
    episodes = data.get('episodes', {})
    fanart = os.path.join(ADDON_PATH, 'fanart.jpg')
    
    # Sezonları listele
    for season_num in sorted(episodes.keys(), key=int):
        season_name = f"Sezon {season_num}"
        # Eğer sunucuda özel sezon ismi varsa onu bul
        for s_info in seasons_data:
            if str(s_info.get('season_number')) == str(season_num):
                season_name = s_info.get('name') or season_name
                break
        
        list_item = ListItem(season_name)
        list_item.setArt({'fanart': fanart})
        url = build_url({'action': 'episodes', 'series_id': series_id, 'season_num': season_num})
        addDirectoryItem(HANDLE, url, list_item, isFolder=True)
        
    endOfDirectory(HANDLE)

def list_episodes(series_id, season_num):
    api = get_api()
    if not api: return
    
    data = api.get_series_info(series_id)
    episodes = data.get('episodes', {}).get(str(season_num), [])
    fanart = os.path.join(ADDON_PATH, 'fanart.jpg')
    
    for ep in episodes:
        title = ep.get('title') or f"Bölüm {ep.get('episode_num')}"
        stream_id = ep.get('id')
        container = ep.get('container_extension') or 'mp4'
        
        list_item = ListItem(title)
        list_item.setInfo('video', {
            'plot': ep.get('info', {}).get('plot', ''),
            'duration': ep.get('info', {}).get('duration', '')
        })
        list_item.setArt({'thumb': ep.get('info', {}).get('movie_image'), 'fanart': fanart})
        
        url = build_url({'action': 'play', 'type': 'series', 'id': stream_id, 'container': container, 'name': title})
        list_item.setProperty('IsPlayable', 'true')
        addDirectoryItem(HANDLE, url, list_item, isFolder=False)
            
    endOfDirectory(HANDLE)

def play_item(params):
    api = get_api()
    if not api: return
    
    stream_id = params.get('id')
    content_type = params.get('type')
    item_name = params.get('name', 'İçerik')
    
    # Uzantı kontrolü
    container = params.get('container')
    if not container or str(container) == 'None':
        container = 'ts' if content_type == 'live' else 'mp4'
    
    url = api.get_stream_url(stream_id, content_type, container)
    
    # User-Agent ve Referer ekleyerek sunucu engellemesini asma (Miracle Fix)
    ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    if url:
        url += f"|User-Agent={ua}&Referer={api.base_url}/"

    log(f"Oynatma baslatildi: {item_name} (ID: {stream_id}, Tip: {content_type})")
    log(f"DEBUG URL: {url}")

    if not url or not stream_id:
        Dialog().notification('Hata', 'ID bulunamadı, oynatılamıyor.', xbmcgui.NOTIFICATION_ERROR)
        return

    # ListItem oluştur ve path ata
    list_item = ListItem(item_name, path=url)
    
    # Medya türünü belirterek dekoder uyumluluğunu artır
    m_type = 'movie' if content_type == 'vod' else 'episode' if content_type == 'series' else 'video'
    list_item.setInfo('video', {'title': item_name, 'mediatype': m_type})
    
    setResolvedUrl(HANDLE, True, list_item)

def router(params):
    action = params.get('action')
    
    if not action:
        main_menu()
    elif action == 'categories':
        list_categories(params.get('type'))
    elif action == 'list':
        list_content(params.get('type'), params.get('cat_id'))
    elif action == 'seasons':
        list_seasons(params.get('series_id'))
    elif action == 'episodes':
        list_episodes(params.get('series_id'), params.get('season_num'))
    elif action == 'play':
        play_item(params)
    elif action == 'settings':
        ADDON.openSettings()

if __name__ == '__main__':
    router(get_params())
