import requests

class XtreamAPI:
    def __init__(self, base_url, username, password):
        self.base_url = base_url.rstrip('/')
        self.username = username
        self.password = password
        self.session = requests.Session()

    def authenticate(self):
        try:
            url = f"{self.base_url}/player_api.php"
            params = {
                "username": self.username,
                "password": self.password
            }
            response = self.session.get(url, params=params, timeout=10)
            data = response.json()
            
            if "user_info" in data and data["user_info"]["auth"] == 1:
                return True, data
            else:
                return False, "Hatalı giriş bilgileri."
        except Exception as e:
            return False, f"Bağlantı hatası: {str(e)}"

    def get_categories(self, type="live"):
        # types: live, vod, series
        action = f"get_{type}_categories"
        return self._get_action(action)

    def get_streams(self, category_id, type="live"):
        # types: live, vod, series
        action = f"get_{type}_streams" if type != "series" else "get_series"
        params = {"action": action}
        if category_id and category_id != "0":
            params["category_id"] = category_id
        return self._get_action_with_params(params)

    def get_series_info(self, series_id):
        return self._get_action_with_params({"action": "get_series_info", "series_id": series_id})

    def _get_action(self, action):
        return self._get_action_with_params({"action": action})

    def _get_action_with_params(self, additional_params):
        try:
            url = f"{self.base_url}/player_api.php"
            params = {
                "username": self.username,
                "password": self.password
            }
            params.update(additional_params)
            response = self.session.get(url, params=params, timeout=15)
            return response.json()
        except Exception:
            return []

    def get_stream_url(self, stream_id, type="live", container="mp4"):
        # stream_id boşluktan veya None stringinden arındırılmalı
        s_id = str(stream_id).strip()
        if s_id == "None" or not s_id:
            return ""

        # Tip belirleme
        clean_type = str(type).lower().strip()
        if clean_type == "vod": 
            clean_type = "movie"
        
        # Canlı yayınlar için prefix genellikle yoktur
        if clean_type == "live":
            return f"{self.base_url}/{self.username}/{self.password}/{s_id}"
        
        # Uzantı temizleme
        ext = str(container).strip().replace('.', '') if container else "mp4"
        if ext == "None" or not ext:
            ext = "mp4"
            
        # Bazı sunucular /movie/ yerine /vod/ bekliyor olabilir, 
        # ancak standart Xtream /movie/ (VOD) ve /series/ (Dizi) şeklindedir.
        return f"{self.base_url}/{clean_type}/{self.username}/{self.password}/{s_id}.{ext}"

